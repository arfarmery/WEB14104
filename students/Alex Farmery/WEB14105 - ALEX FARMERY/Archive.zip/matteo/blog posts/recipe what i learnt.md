#html +CSS recipe 
##What have i learnt?


From this useful assignment i feel that i have learnt 
more about the setup of an actual html document and the necessary folder and pages needed for it to be realized. I have properly understood the role of CSS in webpages and also have learnt about webkit animation only availabe in Safari and Chrome.

Learnt to push work through github

I have also learnt interesting ways yo edit code at a faster pace, e.g. importing from bootstrap or using a boiler plate in the beggining. 

understood what is necessary in a business pitch in terms of pages process etc..

In future i would really like to learn; How to set up local host server to be able to preview site locally.
set up wordpress in conjuction with dreamweaver and **MAMP** for existing domain registered, live, working site.
learn to edit CSS of existing website. 
Learn to understand Xcode
Learn how to create prototype apps in **Xcode** 
