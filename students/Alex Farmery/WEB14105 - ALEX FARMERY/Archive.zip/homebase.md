**Home Base**

my folder is named; WEB14105 ALEX FARMERY

Inside folder another called 'matteo' (so you know its for you matteo;))

Analysis of bad website; In folder>blogposts>matteo posts> 1st

The matteo posts.pdf contains all my blog posts, along with action plan, recipe re-design information and mocks ups of re-designed website. Another post about what i learn in in the 'blog posts' folder; named recipe what i learnt.md (**another what i learnt is in the main 'matteo folder')

Within 'matteo' there are 2 wireframes, corresponding to some of my first ideas for the website redesign. 

There is also a single seperate 'skinmusic.css' so you can see the css which is running live on skinmusic.com. (Due to client wanting some specific last minuite tweaks, i jave put it there so you can see what has been applied.)

within 'skinmusic' there are all files for corresponding website. within styles you can access all css files, including my 'reset.css' that skinmusic.com is running off. 
You can see my commenting on it also (because i was kind of teaching myself as i was going along).

'recipe-boot' can be pulled into a chrome window and index.html will display my recipe webpage. The blog entires for this are within 'matteo posts.pdf'

here is my link to vimeo presentations 
https://vimeo.com/user41022607
